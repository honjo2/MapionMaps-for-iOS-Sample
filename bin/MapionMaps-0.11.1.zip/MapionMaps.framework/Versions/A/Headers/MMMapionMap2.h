//
//  MMMapionMap2.h
//  MapionMaps
//
//  Created by honjyo on 12/11/15.
//  Copyright (c) 2012年 Mapion Co.,Ltd. All rights reserved.
//

#import <MapionMaps/MapionMaps.h>

@interface MMMapionMap2 : MMAbstractEPSG900913Map

@end
