//
//  MMAbstractEPSG900913Map.h
//  MapionMaps
//
//  Created by honjo on 12/05/09.
//  Copyright (c) 2012 Mapion Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMMap.h"

@interface MMAbstractEPSG900913Map : NSObject <MMMap>

@end
